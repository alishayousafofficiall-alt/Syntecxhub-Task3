import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { taskAPI } from '../utils/api';
import TaskCard from '../components/TaskCard';
import TaskModal from '../components/TaskModal';
import toast from 'react-hot-toast';
import './Dashboard.css';

const Dashboard = () => {
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [summary, setSummary] = useState({ total: 0, todo: 0, inProgress: 0, completed: 0 });
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [filters, setFilters] = useState({ status: '', priority: '', search: '' });

  const fetchTasks = useCallback(async () => {
    try {
      const params = {};
      if (filters.status) params.status = filters.status;
      if (filters.priority) params.priority = filters.priority;
      if (filters.search) params.search = filters.search;
      const res = await taskAPI.getAll(params);
      setTasks(res.data.tasks);
      setSummary(res.data.summary);
    } catch (err) {
      toast.error('Failed to load tasks');
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const handleCreate = async (data) => {
    try {
      await taskAPI.create(data);
      toast.success('Task created!');
      fetchTasks();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create task');
      throw err;
    }
  };

  const handleUpdate = async (data) => {
    try {
      await taskAPI.update(editTask._id, data);
      toast.success('Task updated!');
      fetchTasks();
    } catch (err) {
      toast.error('Failed to update task');
      throw err;
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this task?')) return;
    try {
      await taskAPI.delete(id);
      toast.success('Task deleted');
      fetchTasks();
    } catch (err) {
      toast.error('Failed to delete task');
    }
  };

  const handleStatusChange = async (id, status) => {
    try {
      await taskAPI.update(id, { status });
      toast.success('Status updated');
      fetchTasks();
    } catch (err) {
      toast.error('Failed to update status');
    }
  };

  const openCreate = () => { setEditTask(null); setModalOpen(true); };
  const openEdit = (task) => { setEditTask(task); setModalOpen(true); };

  const handleFilterChange = (e) =>
    setFilters((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const clearFilters = () => setFilters({ status: '', priority: '', search: '' });

  return (
    <div className="dashboard">
      <div className="container">
        {/* Header */}
        <div className="dash-header">
          <div>
            <h1 className="dash-title">My Tasks</h1>
            <p className="dash-sub">Hey {user?.name?.split(' ')[0]} 👋 Let's get things done</p>
          </div>
          <button className="btn btn-primary" onClick={openCreate}>
            + New Task
          </button>
        </div>

        {/* Stats */}
        <div className="stats-grid">
          <div className="stat-card">
            <span className="stat-num">{summary.total}</span>
            <span className="stat-label">Total</span>
          </div>
          <div className="stat-card todo">
            <span className="stat-num">{summary.todo}</span>
            <span className="stat-label">To Do</span>
          </div>
          <div className="stat-card inprogress">
            <span className="stat-num">{summary.inProgress}</span>
            <span className="stat-label">In Progress</span>
          </div>
          <div className="stat-card completed">
            <span className="stat-num">{summary.completed}</span>
            <span className="stat-label">Completed</span>
          </div>
        </div>

        {/* Filters */}
        <div className="filters-bar">
          <input
            className="form-control filter-search"
            name="search"
            value={filters.search}
            onChange={handleFilterChange}
            placeholder="🔍 Search tasks..."
          />
          <select className="form-control filter-select" name="status" value={filters.status} onChange={handleFilterChange}>
            <option value="">All Status</option>
            <option value="todo">To Do</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
          </select>
          <select className="form-control filter-select" name="priority" value={filters.priority} onChange={handleFilterChange}>
            <option value="">All Priority</option>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
          {(filters.status || filters.priority || filters.search) && (
            <button className="btn btn-outline btn-sm" onClick={clearFilters}>Clear</button>
          )}
        </div>

        {/* Tasks Grid */}
        {loading ? (
          <div className="spinner"><div className="spinner-ring"></div></div>
        ) : tasks.length === 0 ? (
          <div className="empty-state">
            <div style={{ fontSize: 48, marginBottom: 12 }}>📋</div>
            <h3>No tasks found</h3>
            <p>Click "New Task" to add your first task</p>
          </div>
        ) : (
          <div className="tasks-grid">
            {tasks.map((task) => (
              <TaskCard
                key={task._id}
                task={task}
                onEdit={openEdit}
                onDelete={handleDelete}
                onStatusChange={handleStatusChange}
              />
            ))}
          </div>
        )}
      </div>

      <TaskModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onSubmit={editTask ? handleUpdate : handleCreate}
        editTask={editTask}
      />
    </div>
  );
};

export default Dashboard;
