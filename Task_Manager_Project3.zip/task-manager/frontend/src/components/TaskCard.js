import React from 'react';
import './TaskCard.css';

const TaskCard = ({ task, onEdit, onDelete, onStatusChange }) => {
  const formatDate = (dateStr) => {
    if (!dateStr) return null;
    const d = new Date(dateStr);
    const now = new Date();
    const isPast = d < now && task.status !== 'completed';
    return {
      formatted: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      isPast
    };
  };

  const due = formatDate(task.dueDate);

  return (
    <div className={`task-card ${task.status === 'completed' ? 'task-completed' : ''}`}>
      <div className="task-card-header">
        <div className="task-status-row">
          <span className={`badge badge-${task.status}`}>
            {task.status === 'in-progress' ? 'In Progress' : task.status.charAt(0).toUpperCase() + task.status.slice(1)}
          </span>
          <span className={`badge badge-${task.priority}`}>{task.priority}</span>
        </div>
        <div className="task-card-actions">
          <button className="icon-btn" onClick={() => onEdit(task)} title="Edit task">✏️</button>
          <button className="icon-btn danger" onClick={() => onDelete(task._id)} title="Delete task">🗑️</button>
        </div>
      </div>

      <h3 className="task-title">{task.title}</h3>

      {task.description && (
        <p className="task-desc">{task.description}</p>
      )}

      <div className="task-card-footer">
        {due && (
          <span className={`task-due ${due.isPast ? 'overdue' : ''}`}>
            📅 {due.isPast ? 'Overdue: ' : ''}{due.formatted}
          </span>
        )}

        <div className="status-changer">
          <select
            value={task.status}
            onChange={(e) => onStatusChange(task._id, e.target.value)}
            className="status-select"
          >
            <option value="todo">To Do</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default TaskCard;
